package com.itheima.DTO;

import lombok.Data;

@Data
public class FeedDTO {
    String content;
    String images;
}
