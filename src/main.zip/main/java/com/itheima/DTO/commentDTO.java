package com.itheima.DTO;

import lombok.Data;

@Data
public class commentDTO {
    Integer id;
    String body;
}
