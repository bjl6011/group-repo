package com.itheima.DTO;

import lombok.Data;

@Data
public class loginDTO {

    String username;
    String password;
}
