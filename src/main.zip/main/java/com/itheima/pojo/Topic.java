package com.itheima.pojo;

public class Topic {
}
